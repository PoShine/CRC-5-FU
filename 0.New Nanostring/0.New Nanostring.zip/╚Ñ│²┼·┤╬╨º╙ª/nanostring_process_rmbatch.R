rm(list = ls())
library(NanoStringNorm)
setwd("F:/210E盘文档/colon cancer/0DataAndScript/0.New Nanostring")
# read in all the rcc files
#batch1
data.raw.batch1 <- read.markup.RCC(rcc.path = "New nanostring data/batch1_Keeli_Cartridges_1,2",
                                   rcc.pattern = "*.RCC|*.rcc",
                                   exclude = NULL,
                                   include = NULL,
                                   nprobes = -1)
colnames(data.raw.batch1$x)[4:dim(data.raw.batch1$x)[2]] <- toupper(data.raw.batch1$header["sample.id",])
nanostring.mRNA.batch1 <- data.raw.batch1$x
# normalize
nanostring.mRNA.batch1.norm <- NanoStringNorm(x = nanostring.mRNA.batch1,
                                              anno = NA,
                                              CodeCount = 'geo.mean',
                                              Background = 'mean',
                                              SampleContent = 'housekeeping.geo.mean',
                                              round.values = TRUE,
                                              take.log = TRUE,
                                              return.matrix.of.endogenous.probes = TRUE)
batch1 <- data.frame(row.names = colnames(nanostring.mRNA.batch1.norm),
                     batchID = rep(1,dim(nanostring.mRNA.batch1.norm)[2]),stringsAsFactors = F)


#batch2
data.raw.batch2 <- read.markup.RCC(rcc.path = "New nanostring data/batch2_Keeli_Cartridges_3,4,5",
                                   rcc.pattern = "*.RCC|*.rcc",
                                   exclude = NULL,
                                   include = NULL,
                                   nprobes = -1)
colnames(data.raw.batch2$x)[4:dim(data.raw.batch2$x)[2]] <- toupper(data.raw.batch2$header["sample.id",])
nanostring.mRNA.batch2 <- data.raw.batch2$x
# normalize
nanostring.mRNA.batch2.norm <- NanoStringNorm(x = nanostring.mRNA.batch2,
                                              anno = NA,
                                              CodeCount = 'geo.mean',
                                              Background = 'mean',
                                              SampleContent = 'housekeeping.geo.mean',
                                              round.values = TRUE,
                                              take.log = TRUE,
                                              return.matrix.of.endogenous.probes = TRUE)
batch2 <- data.frame(row.names = colnames(nanostring.mRNA.batch2.norm),
                     batchID = rep(2,dim(nanostring.mRNA.batch2.norm)[2]),stringsAsFactors = F)


#batch3
data.raw.batch3 <- read.markup.RCC(rcc.path = "New nanostring data/batch3_Keeli_Cartridges_6,7,8",
                                   rcc.pattern = "*.RCC|*.rcc",
                                   exclude = NULL,
                                   include = NULL,
                                   nprobes = -1)
colnames(data.raw.batch3$x)[4:dim(data.raw.batch3$x)[2]] <- toupper(data.raw.batch3$header["sample.id",])
nanostring.mRNA.batch3 <- data.raw.batch3$x
# normalize
nanostring.mRNA.batch3.norm <- NanoStringNorm(x = nanostring.mRNA.batch3,
                                              anno = NA,
                                              CodeCount = 'geo.mean',
                                              Background = 'mean',
                                              SampleContent = 'housekeeping.geo.mean',
                                              round.values = TRUE,
                                              take.log = TRUE,
                                              return.matrix.of.endogenous.probes = TRUE)
batch3 <- data.frame(row.names = colnames(nanostring.mRNA.batch3.norm),
                     batchID = rep(3,dim(nanostring.mRNA.batch3.norm)[2]),stringsAsFactors = F)


#batch4
data.raw.batch4 <- read.markup.RCC(rcc.path = "New nanostring data/batch4_Keeli_Cartridges_9,10",
                                   rcc.pattern = "*.RCC|*.rcc",
                                   exclude = NULL,
                                   include = NULL,
                                   nprobes = -1)
colnames(data.raw.batch4$x)[4:dim(data.raw.batch4$x)[2]] <- toupper(data.raw.batch4$header["sample.id",])
nanostring.mRNA.batch4 <- data.raw.batch4$x
# normalize
nanostring.mRNA.batch4.norm <- NanoStringNorm(x = nanostring.mRNA.batch4,
                                              anno = NA,
                                              CodeCount = 'geo.mean',
                                              Background = 'mean',
                                              SampleContent = 'housekeeping.geo.mean',
                                              round.values = TRUE,
                                              take.log = TRUE,
                                              return.matrix.of.endogenous.probes = TRUE)
batch4 <- data.frame(row.names = colnames(nanostring.mRNA.batch4.norm),
                     batchID = rep(4,dim(nanostring.mRNA.batch4.norm)[2]),stringsAsFactors = F)

#batch5
data.raw.batch5 <- read.markup.RCC(rcc.path = "New nanostring data/batch5_Keeli_Cartridges_11,12",
                                   rcc.pattern = "*.RCC|*.rcc",
                                   exclude = NULL,
                                   include = NULL,
                                   nprobes = -1)
colnames(data.raw.batch5$x)[4:dim(data.raw.batch5$x)[2]] <- toupper(data.raw.batch5$header["sample.id",])
nanostring.mRNA.batch5 <- data.raw.batch5$x
# normalize
nanostring.mRNA.batch5.norm <- NanoStringNorm(x = nanostring.mRNA.batch5,
                                              anno = NA,
                                              CodeCount = 'geo.mean',
                                              Background = 'mean',
                                              SampleContent = 'housekeeping.geo.mean',
                                              round.values = TRUE,
                                              take.log = TRUE,
                                              return.matrix.of.endogenous.probes = TRUE)
batch5 <- data.frame(row.names = colnames(nanostring.mRNA.batch5.norm),
                     batchID = rep(5,dim(nanostring.mRNA.batch5.norm)[2]),stringsAsFactors = F)


##
merge_expression <- cbind(nanostring.mRNA.batch1.norm,
                          nanostring.mRNA.batch2.norm,
                          nanostring.mRNA.batch3.norm,
                          nanostring.mRNA.batch4.norm,
                          nanostring.mRNA.batch5.norm)
batch <- rbind(batch1,batch2,batch3,batch4,batch5)
#combat
modcombat = model.matrix(~1, data=batch)
combat_nanostring = ComBat(dat=as.matrix(merge_expression), batch=batch$batchID, mod=modcombat, 
                           par.prior=TRUE, prior.plots=TRUE)

									   
#save(combat_nanostring,file = "去除批次效应/nanostring.mRNA.norm.RData")


















